package sk.gothmur.mod.blockentity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import sk.gothmur.mod.stone2steel;

import java.util.*;

public class GrindstoneBlockEntity extends BlockEntity {
    public static final float EXHAUST_PER_TICK = 0.0020F;
    public static final double MAX_SPIN_DISTANCE = 4.5D;
    public static final int SPIN_DECAY_TICKS = 14;

    private final Set<UUID> spinningPlayers = new HashSet<>();
    private boolean isSpinning = false;
    private int spinTime = 0;

    public GrindstoneBlockEntity(BlockPos pos, BlockState state) {
        super(stone2steel.GRINDSTONE_BE.get(), pos, state);
    }

    public static void serverTick(ServerLevel level, BlockPos pos, BlockState state, GrindstoneBlockEntity be) {
        // vyčisti neplatných / mimo dosahu
        Iterator<UUID> it = be.spinningPlayers.iterator();
        while (it.hasNext()) {
            UUID id = it.next();
            Player p = level.getPlayerByUUID(id); // 1.21.x vracia Player
            if (p == null || p.isRemoved() || p.isCreative() || p.isSpectator() || tooFar(p, pos)) {
                it.remove();
            }
        }

        if (!be.spinningPlayers.isEmpty()) {
            be.isSpinning = true;
            be.spinTime = SPIN_DECAY_TICKS;
            for (UUID id : new ArrayList<>(be.spinningPlayers)) {
                Player p = level.getPlayerByUUID(id);
                if (p != null && !p.isCreative() && !p.isSpectator()) {
                    p.causeFoodExhaustion(EXHAUST_PER_TICK);
                    if (p.getFoodData().getFoodLevel() <= 0 && p.getFoodData().getSaturationLevel() <= 0) {
                        be.spinningPlayers.remove(id);
                    }
                }
            }
        } else {
            if (be.spinTime > 0) be.spinTime--; else be.isSpinning = false;
        }

        be.setChanged();
        level.sendBlockUpdated(pos, state, state, 3);
    }

    private static boolean tooFar(Player p, BlockPos pos) {
        Vec3 eye = p.getEyePosition();
        double cx = pos.getX() + 0.5, cy = pos.getY() + 0.75, cz = pos.getZ() + 0.5;
        double dx = eye.x - cx, dy = eye.y - cy, dz = eye.z - cz;
        return (dx*dx + dy*dy + dz*dz) > (MAX_SPIN_DISTANCE*MAX_SPIN_DISTANCE);
    }

    public void addSpinner(UUID id) { this.spinningPlayers.add(id); }
    public void removeSpinner(UUID id) { this.spinningPlayers.remove(id); }
    public boolean isSpinning() { return isSpinning; }
    public int getSpinTime() { return spinTime; }

    // --- 1.21.x NBT signatúry s registrami ---
    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider provider) {
        super.loadAdditional(tag, provider);
        this.isSpinning = tag.getBoolean("Spin");
        this.spinTime = tag.getInt("SpinTime");
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider provider) {
        super.saveAdditional(tag, provider);
        tag.putBoolean("Spin", this.isSpinning);
        tag.putInt("SpinTime", this.spinTime);
    }
}
