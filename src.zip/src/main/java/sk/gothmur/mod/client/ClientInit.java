package sk.gothmur.mod.client;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderers;
import net.neoforged.neoforge.common.NeoForge;
import sk.gothmur.mod.stone2steel;

@EventBusSubscriber(modid = stone2steel.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class ClientInit {
    private ClientInit() {}

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        BlockEntityRenderers.register(stone2steel.GRINDSTONE_BE.get(), GrindstoneRenderer::new);
        // Registruj klientský tick na GAME bus bez deprecated anotácií
        NeoForge.EVENT_BUS.addListener(ClientTickEvent.Post.class, KeySpinHandler::onClientTick);
    }
}
