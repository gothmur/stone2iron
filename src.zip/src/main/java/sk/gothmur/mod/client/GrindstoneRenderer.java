package sk.gothmur.mod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.world.level.block.state.BlockState;

import sk.gothmur.mod.blockentity.GrindstoneBlockEntity;
import sk.gothmur.mod.stone2steel;

public class GrindstoneRenderer implements BlockEntityRenderer<GrindstoneBlockEntity> {
    public GrindstoneRenderer(BlockEntityRendererProvider.Context ctx) {}

    @Override
    public void render(GrindstoneBlockEntity be, float partialTicks, PoseStack pose, MultiBufferSource buf, int light, int overlay) {
        boolean spinning = be.isSpinning() || be.getSpinTime() > 0;
        float time = (Minecraft.getInstance().level != null ? (Minecraft.getInstance().level.getGameTime() + partialTicks) : partialTicks);
        float angle = spinning ? (time * 12.5f) % 360f : 0f;

        pose.pushPose();
        pose.translate(0.5, 0.5, 0.5);
        if (spinning) pose.mulPose(Axis.YP.rotationDegrees(angle));
        pose.translate(-0.5, -0.5, -0.5);

        BlockState self = stone2steel.GRINDSTONE.get().defaultBlockState();
        BlockRenderDispatcher d = Minecraft.getInstance().getBlockRenderer();
        d.renderSingleBlock(self, pose, buf, light, overlay);
        pose.popPose();
    }
}
