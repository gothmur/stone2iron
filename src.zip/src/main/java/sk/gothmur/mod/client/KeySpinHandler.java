package sk.gothmur.mod.client;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import sk.gothmur.mod.network.GrindNetworking;
import sk.gothmur.mod.stone2steel;

public final class KeySpinHandler {
    private KeySpinHandler() {}
    private static boolean wasHolding = false;
    private static BlockPos currentPos = null;

    public static void onClientTick(ClientTickEvent.Post evt) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        if (mc.isPaused() || mc.screen != null) { sendStopIfNeeded(); return; }

        boolean holdingUse = mc.options.keyUse.isDown();
        BlockPos lookingAt = getGrindstoneLookedAt(mc);

        if (holdingUse && lookingAt != null) {
            if (!wasHolding || currentPos == null || !currentPos.equals(lookingAt)) {
                currentPos = lookingAt.immutable();
                GrindNetworking.sendSpinToServer(currentPos, true);
            }
            wasHolding = true;
        } else {
            sendStopIfNeeded();
        }
    }

    private static void sendStopIfNeeded() {
        if (wasHolding && currentPos != null) {
            GrindNetworking.sendSpinToServer(currentPos, false);
        }
        wasHolding = false;
        currentPos = null;
    }

    private static BlockPos getGrindstoneLookedAt(Minecraft mc) {
        HitResult hr = mc.hitResult;
        if (!(hr instanceof BlockHitResult bhr)) return null;
        BlockPos pos = bhr.getBlockPos();
        Block b = mc.level.getBlockState(pos).getBlock();
        return (b == stone2steel.GRINDSTONE.get()) ? pos : null;
    }
}
