package sk.gothmur.mod.network;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import sk.gothmur.mod.blockentity.GrindstoneBlockEntity;
import sk.gothmur.mod.stone2steel;

@EventBusSubscriber(modid = stone2steel.MODID, bus = EventBusSubscriber.Bus.MOD)
public final class GrindNetworking {
    private GrindNetworking() {}

    @SubscribeEvent
    public static void register(final RegisterPayloadHandlersEvent event) {
        event.registrar(stone2steel.MODID)
                .playToServer(C2SGrindSpin.TYPE, C2SGrindSpin.STREAM_CODEC, (msg, ctx) -> {
                    ctx.enqueueWork(() -> {
                        Player p0 = ctx.player();              // v 1.21.x vracia Player
                        if (!(p0 instanceof ServerPlayer sender)) return;
                        ServerLevel level = sender.serverLevel();
                        BlockEntity be = level.getBlockEntity(msg.pos());
                        if (be instanceof GrindstoneBlockEntity g) {
                            if (msg.start()) g.addSpinner(sender.getUUID());
                            else g.removeSpinner(sender.getUUID());
                        }
                    });
                    // ctx.setHandled(true); // v 1.21.x netreba ani nie je
                });
    }

    // Klient -> server odoslanie
    public static void sendSpinToServer(BlockPos pos, boolean start) {
        var con = Minecraft.getInstance().getConnection();
        if (con != null) con.send(new C2SGrindSpin(pos, start));
    }
}
